function OAuthToken(key, secret) {
    this.key = key;
    this.secret = secret;
}

module.exports = OAuthToken;